# Projeto API Calculadora

Esse projeto visa praticar conceitos de gestão e qualidade de software.

# Links Importantes

- [Iniciando no framework Jooby (tradução PT-BR)](https://translate.google.com/translate?sl=auto&tl=pt&u=https://jooby.io/%23getting-started)