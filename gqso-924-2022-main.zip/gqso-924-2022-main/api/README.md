# api

Welcome to api!!

## running

    mvn clean jooby:run

## building

    mvn clean package

